import User from "../models/user.model.js";
import Message from "../models/message.model.js";
import { generateChatSuggestion } from "../lib/gemini.js";
import cloudinary from "../lib/cloudinary.js";
import { getReceiverSocketId, io } from "../lib/socket.js";

export const getUsersForSidebar = async (req, res) => {
  try {
    const loggedInUserId = req.user._id;
    const filteredUsers = await User.find({ _id: { $ne: loggedInUserId } }).select("-password");

    res.status(200).json(filteredUsers);
  } catch (error) {
    console.error("Error in getUsersForSidebar: ", error.message);
    res.status(500).json({ error: "Internal server error" });
  }
};

export const getMessages = async (req, res) => {
  try {
    const { id: userToChatId } = req.params;
    const myId = req.user._id;

    const messages = await Message.find({
      $or: [
        { senderId: myId, receiverId: userToChatId },
        { senderId: userToChatId, receiverId: myId },
      ],
    });

    res.status(200).json(messages);
  } catch (error) {
    console.log("Error in getMessages controller: ", error.message);
    res.status(500).json({ error: "Internal server error" });
  }
};

export const getChatSuggestion = async (req, res) => {
  try {
    const { message } = req.body;
    const { id: receiverId } = req.params;
    const senderId = req.user._id;

    console.log('Request details:', {
      message,
      receiverId,
      senderId,
      body: req.body,
      params: req.params,
      user: req.user
    });

    // Get the relationship between users
    const sender = await User.findById(senderId);
    console.log('Sender user:', sender);

    if (!sender) {
      console.error('Sender not found:', senderId);
      return res.status(404).json({ error: "Sender user not found" });
    }

    const relationship = sender.relationships.find(rel => rel.userId.toString() === receiverId);
    console.log('Found relationship:', relationship);

    if (!relationship) {
      console.error('No relationship found between users:', { senderId, receiverId });
      return res.status(400).json({ error: "No relationship defined with this user" });
    }

    // Generate suggestion using Gemini
    console.log('Generating suggestion with relationship:', relationship.relationship);
    const suggestion = await generateChatSuggestion(message, relationship.relationship);
    console.log('Generated suggestion:', suggestion);
    
    res.status(200).json({ suggestion });
  } catch (error) {
    console.error("Error in getChatSuggestion controller:", {
      message: error.message,
      stack: error.stack,
      error: error
    });
    res.status(500).json({ 
      error: "Internal server error",
      details: error.message,
      stack: process.env.NODE_ENV === 'development' ? error.stack : undefined
    });
  }
};

export const sendMessage = async (req, res) => {
  try {
    const { text, image } = req.body;
    const { id: receiverId } = req.params;
    const senderId = req.user._id;

    // Get relationship context
    const sender = await User.findById(senderId);
    const relationship = sender.relationships.find(rel => rel.userId.toString() === receiverId);

    let imageUrl;
    if (image) {
      const uploadResponse = await cloudinary.uploader.upload(image);
      imageUrl = uploadResponse.secure_url;
    }

    const newMessage = new Message({
      senderId,
      receiverId,
      text,
      image: imageUrl,
      relationship: relationship ? relationship.relationship : 'other'
    });

    await newMessage.save();

    const receiverSocketId = getReceiverSocketId(receiverId);
    if (receiverSocketId) {
      io.to(receiverSocketId).emit("newMessage", newMessage);
    }

    res.status(201).json(newMessage);
  } catch (error) {
    console.log("Error in sendMessage controller: ", error.message);
    res.status(500).json({ error: "Internal server error" });
  }
};
